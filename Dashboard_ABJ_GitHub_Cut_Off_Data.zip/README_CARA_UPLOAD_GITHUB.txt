CARA UPLOAD DASHBOARD KE GITHUB PAGES

Isi folder/ZIP ini:
- index.html
- database-config.json
- Pemenuhan Kewajiban PAM JAYA PT ABJ dan KPI dalam PKS Bundling.xlsx
- .nojekyll

CARA UPLOAD:
1. Buat repository GitHub baru, contoh: hak-kewajiban-abj.
2. Upload semua file di folder ini ke root repository.
3. Buka Settings > Pages.
4. Source: Deploy from a branch.
5. Branch: main, folder: /root.
6. Klik Save.
7. Buka link GitHub Pages yang muncul.

CARA UPDATE DATABASE:
1. Update file Excel database.
2. Upload/replace file Excel di repository yang sama.
3. Pastikan nama file Excel sama dengan isi database-config.json.
4. Refresh dashboard.

FITUR CUT OFF DATA:
- Dashboard sudah menampilkan pilihan "Update per tanggal".
- Jika file Excel memiliki kolom "Tanggal Cut Off", "Cut Off", "Tanggal Update", atau "Update Per Tanggal", dashboard akan membuat pilihan tanggal otomatis.
- Jika kolom tersebut belum ada, semua data akan masuk ke tanggal defaultCutOffDate di database-config.json.
- Untuk menyimpan beberapa periode, tambahkan kolom "Tanggal Cut Off" di masing-masing sheet, lalu isi tanggalnya, contoh: 2026-07-14 atau 14/07/2026.

NAMA SHEET YANG DIDUKUNG:
- INDUK PT ABJ
- Greenfield PT ABJ
- Brownfield PT ABJ

CATATAN:
- Semua user akan melihat data yang sama selama membuka link GitHub Pages yang sama.
- Data lokal/preview upload hanya untuk testing dan tidak mengubah data orang lain.
